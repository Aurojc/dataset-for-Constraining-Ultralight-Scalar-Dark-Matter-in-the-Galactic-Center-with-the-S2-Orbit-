#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr  5 10:31:34 2026

@author: a23732
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 10 10:37:59 2025

@author: a23732
"""

import csv
import math
import numpy as np
from scipy.integrate import quad
from scipy.integrate import dblquad
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.interpolate import interp1d, CubicSpline
from matplotlib import rcParams
from matplotlib.ticker import LogLocator
from matplotlib.ticker import LogLocator, NullFormatter, LogFormatterSciNotation
import os
from matplotlib.ticker import ScalarFormatter
from matplotlib.ticker import LogLocator, FormatStrFormatter
from matplotlib.ticker import LogLocator, FuncFormatter
from scipy.interpolate import interp1d
# Your data loading and processing code remains the same
data3=np.genfromtxt("alpha_resn.txt")
alpha=data3[:,0]
res=data3[:,1]
data2=np.genfromtxt("alpha_res_gra.txt")
alpha2=data2[:,0]
res2=data2[:,1]
for i in range(len(alpha)):
    res[i] = -res[i]
def schomega(M,a,e):
    return (3*M**1.5/(a**2.5*(1-e**2)))*Pb/np.pi*180*60

def left_lim(M,a,e):
    return ((12.1*0.918-12.1*0.128) - schomega(M,a,e))*np.pi/(180*60)

def right_lim(M,a,e):
    return ((12.1*0.918+12.1*0.128) - schomega(M,a,e))*np.pi/(180*60)

s = 1.8549*10**(43)
hz = 5.391*10**(-44)
AU = 9.256*10**(45)
pc = 1.9092*10**(51)
ms = 9.14*10**(37)
m = 6.187*10**(34)
eV = 8.191*10**(-29)
def f(x):
    return 10**(1.0055*np.log10(x)+25.541)

G = 1
m1 = 4.3*1e6*ms
m2 = 14*ms
mt = m1+m2
mu = m1*m2/(m1+m2)
j = 0
e0 = 0.8844
varphi0 = 0
phi0 = 0
inc = 1
a = 5.016 * 1e-3 * pc
b = a*np.sqrt(1-e0**2)
Pb = 2*np.pi*np.sqrt(a**3/m1)
p = b**2/a
f_cubic = interp1d(alpha, res, kind='cubic') 
alphaa = np.logspace(-4,-2,1000)
ress = f_cubic(alphaa)
f_cubic2 = interp1d(alpha2, res2, kind='cubic') 
alphaa2 = np.logspace(-4,-2,1000)
ress2 = f_cubic2(alphaa2)

N_lam = 1000
lam_range = np.logspace(-14,-19,N_lam)
B, INV_L = np.meshgrid(alphaa, lam_range)
resam = np.zeros_like(B)
lam12 = np.zeros_like(B)
for i in range(N_lam):
    for j in range(len(alphaa)):
        lam12[i,j] = (INV_L[i,j]/(1e9*eV))**2
        resam[i,j]=ress[j]*lam12[i,j]+ress2[j]
    
Llim = left_lim(m1, a, e0)
Rlim = right_lim(m1, a, e0)

allowed = (resam > Llim) & (resam < Rlim)


# Data loading code remains the same...
data=pd.read_csv("pta.csv",header=None)
list=data.values.tolist()
mm1=[item[0] for item in list]
M1=[item[1] for item in list]
beta1 = np.zeros(len(M1))
data2=pd.read_csv("sto.csv",header=None)
list=data2.values.tolist()
mm2=[item[0] for item in list]
M2=[item[1] for item in list]

alpha1=np.zeros(len(mm1))
alpha2=np.zeros(len(mm2))
mm = (alphaa/m1)/eV
for i in range(len(mm1)):
    alpha1[i] = (mm1[i]*m1)*eV
for i in range(len(mm2)):
    alpha2[i] = (mm2[i]*m1)*eV
    

mmin = (10**(-2.6)/m1)/eV
mmin0 = (10**(-5)/m1)/eV
mmax = (1e-1/m1)/eV

eV = 8.191e-29
GeV = 1e9*eV
INV_L = (INV_L/GeV)**2/0.907
for i in range(len(M2)):
    M2[i] = (M2[i]/GeV)**2/0.907




# Set up consistent font settings
from matplotlib.ticker import AutoMinorLocator
from matplotlib.ticker import LogLocator
from matplotlib import rcParams
from matplotlib import rc
import os
os.environ['PATH'] += os.pathsep + '/usr/local/texlive/2025/bin/universal-darwin'
plt.style.use('fivethirtyeight')
plt.rc('text', usetex=True)
plt.rcParams['figure.facecolor'] = 'white'  # 整个图形区域背景颜色
plt.rcParams['axes.facecolor'] = 'white'   # 坐标轴区域背景颜色
plt.rcParams['figure.edgecolor'] = 'white'  # 图形边框颜色
plt.rcParams['font.size'] = 32
plt.rcParams['text.latex.preamble']=r'\usepackage{amsmath}'
plt.rcParams['figure.figsize'] = (14, 10)
plt.rcParams['axes.labelsize'] = plt.rcParams['font.size']
plt.rcParams['axes.titlesize'] = 1.4*plt.rcParams['font.size']
plt.rcParams['legend.fontsize'] = plt.rcParams['font.size']
plt.rcParams['xtick.labelsize'] = plt.rcParams['font.size']
plt.rcParams['ytick.labelsize'] = plt.rcParams['font.size']
plt.rcParams['xtick.major.size'] = 6
plt.rcParams['xtick.minor.size'] = 3
plt.rcParams['xtick.major.width'] = 1
plt.rcParams['xtick.minor.width'] = 1
plt.rcParams['ytick.major.size'] = 6
plt.rcParams['ytick.minor.size'] = 3
plt.rcParams['ytick.major.width'] = 1
plt.rcParams['ytick.minor.width'] = 1
plt.rcParams['legend.frameon'] = True
plt.rcParams['axes.linewidth'] = 1
#plt.rcParams['font.weight'] = 'bold'
fig, ax1 = plt.subplots(figsize=(14, 10))
#fig, ax1 = plt.subplots(figsize=(12, 8))
fig.patch.set_facecolor('white') 
# 强制设置主轴线条可见
for position in ['bottom', 'top', 'left', 'right']:
    ax1.spines[position].set_visible(True)
    ax1.spines[position].set_color('black')
    ax1.spines[position].set_linewidth(2)

# First x-axis (bottom)

'''ax1.xaxis.set_major_locator(LogLocator(base=100.0))#主刻度
ax1.xaxis.set_minor_locator(LogLocator(base=10.0, numticks=999,subs=np.linspace(0, 1.0, 10 + 2)[1:-1]))#次刻度

ax1.yaxis.set_major_locator(LogLocator(base=10.0))#主刻度
ax1.yaxis.set_minor_locator(LogLocator(base=10.0, numticks=999,subs=np.linspace(0, 1.0, 10 + 2)[1:-1]))#次刻度'''
# 将 x 轴的刻度移到上方

'''minor_ticks = [1e-7, 1e-6, 1e-4, 1e-3, 1e-1, 1e0, 1e2]
ax1.set_yticks(minor_ticks, minor=True)'''
#ax1.set_yticklabels([], minor=True)
#ax1.yaxis.set_minor_locator(LogLocator(base=10.0, subs=np.arange(1.0, 10.0) * 0.1, numticks=1000))
#ax1.yaxis.set_minor_formatter(plt.NullFormatter())
ax1.tick_params(axis='x', direction='in', length=4, which='both', pad=10, top=True)
ax1.tick_params(axis='x', direction='in', length=6, which='major', pad=10, top=True, width=2.5)
ax1.grid(which='major', color='darkgrey', linestyle='-', linewidth=1, zorder=0)
ax1.grid(axis='y', which='minor', color='lightgrey', linestyle='--', linewidth=1, zorder=0)


#ax1.loglog(alpha2, M2, 'g-', label='$\mathrm{Cassini}$')
ax1.contourf(B, INV_L, allowed, levels=[0, 0.5, 1], colors=[(0,0,0,0), 'lightblue'])
ax1.loglog(alpha2, f(mm2), 'y-', label='$\mathrm{MICROSCOPE}$')
#ax1.loglog(alpha1, M1, 'y-', label='$\mathrm{PTA}$')

ax1.tick_params(width=2.5,labelsize=35, which='major', direction='in', pad=10, 
                              length=6, top=bool, right=bool) 
ax1.set_xlabel(r"$\alpha$",fontsize=42,labelpad=10)
ax1.set_ylabel(r"$d_g^{(2)}$",fontsize=42,labelpad=18)
y_min, y_max = ax1.get_ylim()

# Fill between areas
dot_legend = plt.Line2D([], [], marker='s', color='none',
                       markerfacecolor='lightblue', 
                       markersize=12,
                       markeredgecolor='none',
                       label='$\mathrm{Allowed\,\,region}$')

dash_legend = plt.Line2D([], [], color='y',
                        linestyle='-',
                        linewidth=2.8,
                        label='$\mathrm{MICROSCOPE}$')


#ax1.tick_params(width=2.5, which='major', direction='in', pad=10, length=6)
ax1.set_xlim(1e-4, 1e-2)
#ax1.set_ylim(1e-8, 5e3)
ax1.set_ylim(1e3, 1e9)
ax1.legend(handles=[dash_legend], #dot_legend, 
           loc=4,fontsize=26)

# Second x-axis (top)
ax2 = ax1.twiny()
for position in ['bottom', 'top', 'left', 'right']:
    ax2.spines[position].set_visible(True)
    ax2.spines[position].set_color('black')
    ax2.spines[position].set_linewidth(2)
ax2.xaxis.set_major_locator(LogLocator(base=100.0))#主刻度
ax2.xaxis.set_minor_locator(LogLocator(base=10.0, numticks=999,subs=np.linspace(0, 1.0, 10 + 2)[1:-1]))#次刻度

# 将主刻度加粗
ax1.tick_params(axis='x', direction='in', length=4, which='minor', width=1.5)
ax2.tick_params(axis='x', direction='in', length=4, which='minor', width=1.5, top=True)
# 调整上 x 轴的主刻度粗细
ax2.tick_params(axis='x', direction='in', length=6, which='major', pad=10, top=True, width=2.5)

M, INV_L2 = np.meshgrid(mm, lam_range)
#ax2.loglog(mm2, M2, 'g-', label='$\mathrm{Cassini}$')
ax2.contourf(M, INV_L, allowed, levels=[0, 0.5, 1], colors=[(0,0,0,0), 'lightblue'])
ax2.loglog(mm2, f(mm2), 'y-', label='$\mathrm{MICROSCOPE}$')
#ax2.loglog(mm1, M1, 'y-', label='$\mathrm{PTA}$')
ax2.set_xlabel(r"$m\,\mathrm{[eV]}$",fontsize=42,labelpad=10)
#ax2.margins(y=0)
ax2.tick_params(width=2.5,labelsize=35, which='major', direction='in', pad=7, 
                              length=6, top=bool, right=bool) 
ax2.set_xlim((1e-4/m1)/eV, (1e-2/m1)/eV)
ax2.set_ylim(1e3, 1e9)
minor_ticks = [1e3, 1e5, 1e7, 1e9]
ax1.set_yticks(minor_ticks, minor=True)
ax1.set_yticklabels([], minor=True)
ax1.tick_params(axis='y', direction='in', length=4, which='minor', width=2, right=True)

#ax1.yaxis.set_major_locator(LogLocator(base=10.0, subs=tick)) 
#ax2.tick_params(axis='x', which='major', pad=0) 
#ax2.xaxis.set_label_coords(0.58, 1.1)
#plt.tight_layout()
#plt.subplots_adjust(left=0.15, right=0.85, bottom=0.15, top=0.85)
#plt.figure(figsize=(4, 3), dpi=300)
plt.subplots_adjust(left=0.145 , bottom=0.13, top=0.85)
plt.savefig('fig3-2.png', dpi=300, facecolor='white')
plt.show()