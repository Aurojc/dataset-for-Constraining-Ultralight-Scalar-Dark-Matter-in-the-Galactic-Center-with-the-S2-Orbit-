#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr  5 11:02:56 2026

@author: a23732
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 10 09:59:26 2025

@author: a23732
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy.interpolate import interp1d
import os
os.environ['PATH'] += os.pathsep + '/usr/local/texlive/2025/bin/universal-darwin'
plt.style.use('fivethirtyeight')
plt.rc('text', usetex=True)
plt.rcParams['figure.facecolor'] = 'white'  # 整个图形区域背景颜色
plt.rcParams['axes.facecolor'] = 'white'   # 坐标轴区域背景颜色
plt.rcParams['figure.edgecolor'] = 'white'  # 图形边框颜色
plt.rcParams['font.size'] = 32
plt.rcParams['text.latex.preamble']=r'\usepackage{amsmath}'
plt.rcParams['figure.figsize'] = (14, 10)
plt.rcParams['axes.labelsize'] = plt.rcParams['font.size']
plt.rcParams['axes.titlesize'] = 1.4*plt.rcParams['font.size']
plt.rcParams['legend.fontsize'] = plt.rcParams['font.size']
plt.rcParams['xtick.labelsize'] = plt.rcParams['font.size']
plt.rcParams['ytick.labelsize'] = plt.rcParams['font.size']
plt.rcParams['xtick.major.size'] = 6
plt.rcParams['xtick.minor.size'] = 3
plt.rcParams['xtick.major.width'] = 1
plt.rcParams['xtick.minor.width'] = 1
plt.rcParams['ytick.major.size'] = 6
plt.rcParams['ytick.minor.size'] = 3
plt.rcParams['ytick.major.width'] = 1
plt.rcParams['ytick.minor.width'] = 1
plt.rcParams['legend.frameon'] = True
plt.rcParams['axes.linewidth'] = 1
#plt.rcParams['font.weight'] = 'bold'
fig, ax1 = plt.subplots(figsize=(14, 10))
#fig, ax1 = plt.subplots(figsize=(12, 8))
fig.patch.set_facecolor('white') 
# ... 其他样式设置
#fig, ax1 = plt.subplots(figsize=(12, 8))
fig.patch.set_facecolor('white') 
# 强制设置主轴线条可见
for position in ['bottom', 'top', 'left', 'right']:
    ax1.spines[position].set_visible(True)
    ax1.spines[position].set_color('black')
    ax1.spines[position].set_linewidth(2)
# 读取数据
data4=pd.read_csv("sto.csv",header=None)
list=data4.values.tolist()
m2=[item[0] for item in list]
M2=[item[1] for item in list]
data = np.load('so_1e-3.npz')
data2 = np.load('so_1e-4.npz')
data3 = np.load('0.1.npz')
def f(x):
    return 10**(1.0055*np.log10(x)+25.541)
f_cubic = interp1d(m2, M2, kind='cubic') 
eV = 8.191e-29
GeV = 1e9*eV
alpha1 = 1e-3
alpha2 = 1e-4
alpha3 = 0.1
ms = 9.14e37
m1 = 4.3*10**(6)*ms
mm1 = (alpha1/m1)/eV
mm2 = (alpha2/m1)/eV
mm3 = (alpha3/m1)/eV
y1 = f(mm1)
y2 = f(mm2)
#y3 = f_cubic(mm3)
# 提取数组
B = data['B']
INV_L = (data['L']/GeV)**2/0.907
allowed = data['allowed']

B2 = data2['B']
INV_L2 = (data2['L']/GeV)**2/0.907
allowed2 = data2['allowed']

B3 = data3['B']
INV_L3 = data3['INV_L']
allowed3 = data3['allowed']

from matplotlib.patches import Patch
from matplotlib.lines import Line2D
# 直接绘制图形
ax1.contourf(B2, INV_L2, allowed2, levels=[0, 0.5, 1], 
             colors=[(0,0,0,0), 'lightgreen'])
ax1.contourf(B, INV_L, allowed, levels=[0, 0.5, 1], 
             colors=[(0,0,0,0), 'lightblue'])

# 修改后的图例 - 颜色区域图例
legend_elements = [
    Line2D([0], [0], color='blue', linestyle='--', linewidth=2,
           label=r'$\mathrm{MICROSCOPE\,\, for}\,\,\alpha=10^{-3}$'),
    Line2D([0], [0], color='green', linestyle='--', linewidth=2,
           label=r'$\mathrm{MICROSCOPE\,\, for}\,\,\alpha=10^{-4}$')
]

# 绘制虚线（移除label）
plt.axhline(y=y1, color='b', linestyle='--', linewidth=2)  # 蓝色虚线对应 alpha=1e-3
plt.axhline(y=y2, color='g', linestyle='--', linewidth=2)  # 绿色虚线对应 alpha=1e-4
#plt.axhline(y=y3, color='green', linestyle='--', linewidth=2, label=r'$\alpha=0.1$')

plt.xscale('log')
plt.yscale('log')
plt.xlabel(r'$\beta$',fontsize=42)
plt.ylabel(r'$d_g^{(2)}$',fontsize=42)
ax1.tick_params(axis='x', direction='in', length=6, which='both', pad=10, top=True, width=2.5,labelsize=35)
ax1.tick_params(axis='y', direction='in', length=6, which='both', pad=10, right=True, width=2.5,labelsize=35)
ax1.tick_params(axis='x', direction='in', length=4, which='minor', pad=10, top=True, width=1.5,labelsize=35)
minor_ticks = [1e3, 1e5, 1e7, 1e9]
ax1.set_yticks(minor_ticks, minor=True)
ax1.set_yticklabels([], minor=True)
ax1.tick_params(axis='y', direction='in', length=4, which='minor', width=2, right=True)
#plt.colorbar(label='Allowed (1) / Excluded (0)')
ax1.grid(which='major', color='darkgrey', linestyle='-', linewidth=1, zorder=0)
ax1.grid(axis='y', which='minor', color='lightgrey', linestyle='--', linewidth=1, zorder=0)
plt.subplots_adjust(left=0.125 , bottom=0.135)

# 使用新的图例，字体稍小因为条目较多
plt.legend(handles=legend_elements, loc=1, fontsize=26)

plt.show()
plt.savefig('fig2-2.png', dpi=300, facecolor='white')

# 关闭数据文件
data.close()
data2.close()
data3.close()
'''
# 直接绘制图形

Patch(facecolor='lightblue', edgecolor='none', 
      label=r'$\alpha=10^{-3}$ (allowed region)'),
Patch(facecolor='lightgreen', edgecolor='none',
      label=r'$\alpha=10^{-4}$ (allowed region)'),


ax1.contourf(B2, INV_L2, allowed2, levels=[0, 0.5, 1], 
             colors=[(0,0,0,0), 'lightgreen'])
ax1.contourf(B, INV_L, allowed, levels=[0, 0.5, 1], 
             colors=[(0,0,0,0), 'lightblue'])

dot_legend = plt.Line2D([], [], marker='o', color='none',
                       markerfacecolor='lightblue', 
                       markersize=12,
                       markeredgecolor='none',
                       label='$\mathrm{allowed\,\,region}$')

# 虚线标记
dash_legend = plt.Line2D([], [], color='blue',
                        linestyle='--',
                        linewidth=2,
                        label='$\mathrm{MICROSCOPE}$')

plt.axhline(y=y1, color='b', linestyle='--', linewidth=2, label=r'$\alpha=0.001$')
plt.axhline(y=y2, color='g', linestyle='--', linewidth=2, label=r'$\alpha=0.0001$')
#plt.axhline(y=y3, color='green', linestyle='--', linewidth=2, label=r'$\alpha=0.1$')

plt.xscale('log')
plt.yscale('log')
plt.xlabel(r'$\beta$',fontsize=42)
plt.ylabel(r'$d_g^{(2)}$',fontsize=42)
ax1.tick_params(axis='x', direction='in', length=6, which='both', pad=10, top=True, width=2.5,labelsize=35)
ax1.tick_params(axis='y', direction='in', length=6, which='both', pad=10, right=True, width=2.5,labelsize=35)
ax1.tick_params(axis='x', direction='in', length=4, which='minor', pad=10, top=True, width=1.5,labelsize=35)
minor_ticks = [1e3, 1e5, 1e7, 1e9]
ax1.set_yticks(minor_ticks, minor=True)
ax1.set_yticklabels([], minor=True)
ax1.tick_params(axis='y', direction='in', length=4, which='minor', width=2, right=True)
#plt.colorbar(label='Allowed (1) / Excluded (0)')
ax1.grid(which='major', color='darkgrey', linestyle='-', linewidth=1, zorder=0)
ax1.grid(axis='y', which='minor', color='lightgrey', linestyle='--', linewidth=1, zorder=0)
plt.subplots_adjust(left=0.125 , bottom=0.135)
plt.legend(handles=[dot_legend, dash_legend],
           loc=4)
plt.show()
plt.savefig('fig2-2.png', dpi=300, facecolor='white')

# 关闭数据文件
data.close()
'''